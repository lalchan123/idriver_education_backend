import json
import os

# global function
from FunctionFolder.WrapperFunc import *

def Custom(user, api_name, paramList):
    print("hello")






