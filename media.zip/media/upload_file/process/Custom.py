import json
import os

# global function
from FunctionFolder.WrapperFunc import *

def Custom():
    
    print("hello")



    print("hello")


    print("serevr 2 hello server 2")


    print("k2  abbababa")


    print("hello")


    print("hello custom")


    GoogleNews()


    print("hello")

