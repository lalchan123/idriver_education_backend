import asyncio

import json
import os


# global function
from FunctionFolder.WrapperFunc import *

async def CustomTest(user, api_name, paramList):
    print("async test hello")    
    
    


